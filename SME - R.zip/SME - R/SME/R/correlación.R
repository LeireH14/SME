#' Función para calcular la correlación o información mútua.
#'
#' @description
#' Esta función calcula la correlación (información mútua en el caso de variables categóricas) por pares entre variables de un dataset.
#' @param dataset El dataset del que se quiere calcular la correlación.
#' @return La matriz de correlación del dataset.
#' @examples
#' df <- data.frame(
#' V1 = rnorm(100),
#' V2 = rnorm(100),
#' V3 = factor(sample(1:3, 100, replace = TRUE)),
#' V4 = factor(sample(1:4, 100, replace = TRUE)))
#'
#' correlacion_mutua <- calcular_correlacion_mutua(df)
#'
# Función para calcular la correlación y la información mútua
calcular_correlacion_mutua <- function(dataset) {
  n <- ncol(dataset)
  
  # Se crea una matriz de 0s para guardar los resultados
  correlacion_matriz <- matrix(0, ncol = n, nrow = n)
  colnames(correlacion_matriz) <- names(dataset)
  rownames(correlacion_matriz) <- names(dataset)

  for (i in 1:n) {
    for (j in i:n) {
      if (class(dataset[[i]])=="numeric" && class(dataset[[j]])=="numeric") {
        
        # Se calcula la correlación de Pearson para variables continuas con la función creada más adelante
        correlacion_matriz[i, j] <- calcular_pearson(dataset[[i]], dataset[[j]])
        
      } else if (class(dataset[[i]])=="factor" && class(dataset[[j]])=="factor") {
        
        # Se calcula la información mutua para variables categóricas con la función creada más adelante
        correlacion_matriz[i, j] <- informacion_mutua(dataset[[i]], dataset[[j]])
      } 
      
      # La matriz es simétrica, por lo que se rellenan los datos faltantes de esa forma
      correlacion_matriz[j, i] <- correlacion_matriz[i, j]  
    }
  }
  return(correlacion_matriz)
}

# Función para calcular la información mutua
informacion_mutua <- function(x, y) {
  
  # Se obtienen los valores únicos para la x y la y
  valores_x <- unique(x)
  valores_y <- unique(y)
  
  n <- length(x)
  info_mutua <- 0

  # Se calculan las frecuencias conjuntas y marginales
  for (vx in valores_x) {
    for (vy in valores_y) {
      p_xy <- sum(x == vx & y == vy) / n
      p_x <- sum(x == vx) / n
      p_y <- sum(y == vy) / n
      
      # Se calcula la información mutua
      info_mutua <- info_mutua + p_xy * log2(p_xy / (p_x * p_y)+ 1e-20) # Se suma un pequeño número para evitar indeterminacioens
    }
  }
  return(info_mutua)
}

# Función para calcular la correlación de Pearson
calcular_pearson <- function(x, y) {
  n <- length(x)
  
  # Se calcula la media de x e y
  media_x <- sum(x) / n
  media_y <- sum(y) / n
  
  # Se calcula la covarianza entre x e y
  covarianza <- sum((x - media_x) * (y - media_y))
  
  # Se calcula la desviación estandar de x e y
  desviacion_x <- sqrt(sum((x - media_x)^2))
  desviacion_y <- sqrt(sum((y - media_y)^2))

  # Se calcula la correlación entre x e y 
  correlacion <- covarianza / (desviacion_x * desviacion_y)
  return(correlacion)
}