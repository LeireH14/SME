#' Función para visualizar el ROC (AUC).
#'
#' @description
#' Esta función crea un gráfico para visualizar la curva ROC (AUC).
#' @param atributo El atributo del que se quiere calcular el AUC.
#' @param clase_bin Para la métrica AUC, el dataset debe ser supervisado, es necesario especificar una variable clase binaria con la que evaluar el AUC.
#' @return Un gráfico donde se visualiza la curva ROC del atributo.
#' @details
#' Se requiere la librería ggplot.
#' @examples
#' atributo <- c(1.5, 2.3, 3.1, 4.6, 5.8)
#' clase <- c(TRUE, TRUE, FALSE, TRUE, FALSE)
#' plot_auc(atributo, clase_bin = clase)
#'
# Función para visualizar la curva ROC
plot_auc <- function(atributo, clase_bin){

  # Instala y carga ggplot2 si es necesario
  if(!require(ggplot2)) install.packages("ggplot2")
  library(ggplot2)

  # Se crea un dataset con los valores de la variable y la clase binaria
  data_auc <- matrix(0, nrow = nrow(as.matrix(atributo)), ncol = 2)
  data_auc[,1] <- atributo
  data_auc[,2] <- as.matrix(clase_bin)
  
  # Se calcula el AUC con la función implementada anteriormente
  resultado <- auc_function(data_auc)
  
  # Se calcula la curva ROC (el valor de X es FPR y el valor de y el TPR)
  roc_data <- data.frame(FPR = resultado$FPR, TPR = resultado$TPR)

  # Se plotea la curva ROC
  ggplot(roc_data, aes(x = FPR, y = TPR)) +
    geom_line(color = "blue") +
    ylim(0, 1) +
    labs(title = "Curva ROC", x = "Tasa de Falsos Positivos (FPR)", y = "Tasa de Verdaderos Positivos (TPR)")
}