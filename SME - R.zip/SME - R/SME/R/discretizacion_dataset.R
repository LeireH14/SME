#' Función para discretizar un dataset
#'
#' @description
#' Esta función discretiza un dataset utilizando los métodos igual anchura o igual frecuencia o dándole directamente los puntos de corte a utilizar.
#' @param x El dataset que se quiere discretizar.
#' @param num.bins Para el método igual anchura, el número de intervalos a utilizar.
#' @param method El método que se quiere utilizar para discretizar el dataset. Si method = 1, se utiliza el método igual anchura. Si method = 2, se utilzia el método igual a frecuencia. Por defecto, method = 1.
#' @param cut.points Los puntos de corte que se quieren utilizar para discretizar el dataset. Si la función recibe esta información, no utilizará ningún otro método.
#' @return El dataset discretizado junto con los puntos de corte utilizados.
#' @examples
#' x <- data.frame(V1 = sample(1:100, 10, replace = TRUE),
#' V2 = runif(10, min = 0, max = 1),
#' V3 = rnorm(10, mean = 50, sd = 10))
#'
#'Discretización usando el método de igual anchura con 3 intervalos
#'discretized_data <- discretize_dataset(x, num.bins = 3, method = 1)
#'
#'Discretización usando el método de igual frecuencia con 4 intervalos
#'discretized_data <- discretize_dataset(x, num.bins = 4, method = 2)
#'
discretize_dataset <- function(x, num.bins = NULL, method = 1, cut.points = NULL) {
  dataset <- as.matrix(x)
  
  # Se crea una matriz de 0s para guardar los valores del dataset discretizado y de los cortes
  dataset_discretizado <- matrix(0, nrow = nrow(dataset), ncol = ncol(dataset))
  cortes <- matrix(0, nrow = (num.bins + 1), ncol=ncol(dataset))

  # La discretización se hace por columnas
  for (l in 1:ncol(dataset)){ 
    
    # Se calcula el atributo (la columna) que se va a discretizar
    atributo <- as.matrix(dataset[,l])
    
    # Se utiliza la función para discretizar variables para conseguir los intervalos y los puntos de corte de la columna actual
    resultado <- discretize_v(atributo, num.bins = num.bins, method = method, cut.points = cut.points)
    dataset_discretizado[,l] <- resultado$variable
    cortes[,l] <- resultado$cortes
  }
  return(list(dataset_discretizado, cortes))
}