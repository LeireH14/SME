#' Función para filtrar los atributos de un dataset si no cumplen una condición.
#'
#' @description
#' Esta función calcula una métrica (varrianza, AUC o entropía) y filtra las variables que no cumplan una condición expecificada. Solo calculara la varianza y AUC para variables contínuas y la entropía para las discretas.
#' @param dataset El dataset que se quiere filtrar.
#' @param clase_bin Para la métrica AUC, el dataset debe ser supervisado, es necesario especificar una variable clase binaria con la que evaluar el AUC.
#' @param metric La métrica en la que se quiere basar el filtrado. Pueden ser "entropia", "varianza" o "AUC". Por defecto, "entropia".
#' @param condition String con la condición que deben cumplir las variables. La condición puede ser "<valor", ">valor" o "=valor".  Por defecto, ">1".
#' @return El dataset filtrado. Es decir, el dataset con las variables que cumplen la condición.
#' @examples
#' df <- data.frame(
#' V1 = c(1.5, 2.3, 3.1, 4.6, 5.8),
#' V2 = c(10.2, 15.6, 20.1, 25.5, 30.0),
#' V3 = c(1L, 2L, 3L, 4L, 5L))
#' clase <- c(TRUE, TRUE, FALSE, TRUE, FALSE)
#' dataset_filtrado <- filtrar_dataset(df, clase_bin = clase, metric = "AUC", condition = ">2")
#'
# Función para filtrar un dataset en base a una métrica y una condición
filtrar_dataset <- function (dataset, clase_bin = NULL, metric = "entropia", condition = ">1"){
  
  # Se divide la condición (string) por carácteres
  condition <- strsplit(condition,"")
  
  # Se genera un operador matemático con el primer caracter
  operador <- match.fun(condition[[1]][1])
  
  # Se consigue el valor de la condición con el segundo caracter y se convierte en número
  valor <-  as.numeric(paste(condition[[1]][2:length(condition[[1]])], collapse = ""))
  
  # Se calculan las métricas con la función implementada anteriormente
  results <- metrics(dataset, clase_bin)
  
  columnas <- c()
  count <- 1

  # Si la métrica elegida es la entropía:
  if (metric == "entropia"){
    
    # Se guarda las entropías calculadas y sus columnas
    entropias <- results$entropy$value
    col <- results$entropy$col
    
    # Por cada valor de entropía (cantidad de variables discretas) se ve si cumple la condición establecida
    for (e in entropias){
      if (operador(e, valor)){
        
        # Se guardan solo las columnas que cumplan la condición
        columnas <- c(columnas, col[count])
      }
      # Se sigue un contador para saber qué columna cumplen la condición
      count <- count + 1
    }
  }

  # Si la métrica elegida es el AUC
  else if (metric == "AUC"){
    
    # Se guardan los resultados del AUC y sus columnas
    AUC <- results$auc$value
    col <- results$auc$col
    
    # Por cada AUC calculado, se ve si cumple la condición establecida
    for (a in AUC){
      if (operador(a, valor)){
        
        # Se guardan solo las columnas que cumplen la condición
        columnas <- c(columnas, col[count])
      }
      count <- count + 1
    }
  }
  
  # Si la métrica elegida es la varianza 
  else if (metric == "varianza"){
    
    # Se guardan los resultados de las varianzas y las columnas
    varianza <- results$varianza$value
    col <- results$varianza$col
    
    # Por cada varianza se ve si cumplen la condición y se guaran las columnas de las que la cumplen
    for (v in varianza){
      if (operador(v, valor)){
        columnas <- c(columnas, col[count])
      }
      count <- count + 1
    }
  }
  
  # Se genera un dataset filtrado con las columnas de las que se ha calculado la métrica y que cumplan la condición
  dataset_filtrado <- as.matrix(dataset[,columnas])

  return(dataset_filtrado)
}