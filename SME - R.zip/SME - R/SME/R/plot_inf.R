#' Función para visualizar la información mútua.
#'
#' @description
#' Esta función crea un gráfico tipo heatmap para visualizar la información mútua entre las variables de un dataset.
#' @param dataset El dataset con las variables de las que se quiere calcular la información mútua
#' @return Un gráfico donde se visualiza un gráfico tipo heatmap con la información mútua entre las variables.
#' @details
#' Se requiere la librería corrplot.
#'
plot_info_mutua <- function(df){
  # Se instala y carga el paquete ggplot2 si es necesario
  if(!require(ggplot2)) install.packages("ggplot2")
  library(ggplot2)

  # Se calcula la matriz de correlación/información mútua con la función implementada anteriormente
  correlation_matrix <- calcular_correlacion_mutua(df)

  # Se crea un dataframe vacío para reorganizar los datos a un formato adecuado para plotearlo
  cor_mutua_df <- data.frame(NULL)

# Se rellena el data frame con los datos de la matriz,
  for (i in 1:nrow(correlation_matrix)) {
    for (j in 1:ncol(correlation_matrix)) {
      cor_mutua_df <- rbind(cor_mutua_df, data.frame(
        V1 = rownames(correlation_matrix)[i], 
        V2 = colnames(correlation_matrix)[j],
        val = correlation_matrix[i, j]))
    }
  }

  # Se plotea la matriz de correlación/información mútua
  ggplot(data = cor_mutua_df, aes(x = V1, y = V2, fill = val)) +
    geom_tile(color = "white") +
    scale_fill_gradient2(low = "blue", mid = "white", high = "red", midpoint = 0) +
    labs(title = "Matriz de Correlación e Información Mutua")
}
