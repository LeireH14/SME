#' Función para normalizar un dataset.
#'
#' @description
#' Esta función normaliza un dataset utilizando el método de min-max.
#' @param dataset El dataset que se quiere normalizar.
#' @return El dataset normalizado.
#' @examples
#' df <- data.frame(
#' V1 = c(1.5, 2.3, 3.1, 4.6, 5.8),
#' V2 = c(10.2, 15.6, 20.1, 25.5, 30.0),
#' V3 = c(1.1, 2.2, 1.3, 1.4, 0.95))
#' dataset_normalizado <- normalizar_dataset(df)
#'
# Función para normalizar un dataset
normalizar_dataset <- function(dataset) {
  
  # Se hace una copia del dataset que se quiere normalizar
  dataset_normalizado <- dataset
  for (j in 1:length(dataset)) {
      
    # se calcula la variable normalizada con la función implementada anteriormente y se guarda en la columna actual
    dataset_normalizado[,j] <- normalizar_variable(dataset[,j])
  }
  return(dataset_normalizado)
}