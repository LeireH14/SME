#' Función para calcular métricas para los atributos de un dataset.
#'
#' @description
#' Esta función calcula la varianza y AUC de los atributos para las variables contínuas y la entropía para las discretas.
#' @param dataset El dataset del que se quiere calcular las métricas.
#' @param clase_bin Para la métrica AUC, el dataset debe ser supervisado, es necesario especificar una variable clase binaria con la que evaluar el AUC.
#' @return Una lista con las métricas para cada atributo.
#' @examples
#' df <- data.frame(
#' continua1 = c(1.5, 2.3, 3.1, 4.6, 5.8),
#' continua2 = c(10.2, 15.6, 20.1, 25.5, 30.0),
#' discreta1 = c(1L, 2L, 3L, 4L, 5L))
#' clase <- c(TRUE, TRUE, FALSE, TRUE, FALSE)
#' results <- metrics(df, clase_bin = clase)
#'
metrics <- function(dataset, clase_bin){
  # Se crean vectores vacíos para guardar los resultados de las métricas
  v <- c() # Para guardar las varianzas
  a <- c() # Para los AUC
  e <- c() # Para la entropía
  
  # Se crean vectores vacíos para guardar los números de columna al que pertenecen las métricas
  colv <- c() # Para las columnas de las varianzas
  cole <- c() # Para los de la entropía
  cola <- c() # Para los del AUC

  # Se calcularán las métricas por columna: atributo = columna actual
  for (j in 1:ncol(dataset)) {
    atributo <- as.matrix(dataset[,j])
    
    # Si la clase de dato es "integer" o "factor" (variables contínuas), se calculará el AUC y la varianza
    if (atributo[1,] - as.integer(atributo[1,]) !=0){
      
      # Se utiliza la función para calcular la varianza implementada más adelante y se cuarda el resultado en el vector
      v <- c(v, varianzas_function(atributo))
      
      # Se guarda el número de columna en el vector
      colv <- c(colv, j)
      
      # Se crea la matriz con el atributo y la clase binaria para pasársela a la función implementada más adelante para calcular el AUC
      data_auc <- matrix(0, nrow = nrow(atributo), ncol = 2)
      data_auc[,1] <- atributo
      data_auc[,2] <- as.matrix(clase_bin)
      
      # Se calcula el AUC y se guarda en el vector
      a <- c(a, auc_function(data_auc)$AUC)
      
      # Se guarda el número de columna
      cola <- c(cola, j)
    }
    
    # Si la clase de datos es discreta, se calculará la entropía
    else{
      
      # Se calcula la entroía con la funciónimplementada más adelante y se guarda el valor en el vector
      e <- c(e, entropy_function(atributo))
      
      # Se guarda el número de columna
      cole <- c(cole, j)
    }
    
    # Se crean listas con las métricas calculadas y sus columnas
    entropy <- list(value = e, col = cole)
    auc <- list(value = a, col = cola)
    varianza <- list(value = v, col = colv)

  }
  return(list(varianza = varianza, auc = auc, entropy = entropy))
}


# Función para calcular la varianza
varianzas_function <- function(atributo) {

  # Calcular la media de la columna
  media <- sum(atributo) / length(atributo)

  sum_square <- 0
  
  # Calcular la suma de los cuadrados de las diferencias con la media
  for (i in 1:length(atributo)) {
    sum_square <- sum_square + (atributo[i] - media)^2
  }

  # Calcular la varianza
  varianza <- sum_square / (length(atributo) - 1)

  return(varianza)
}


# Función para calcular la entropía
entropy_function <- function(x) {
  
  # Se consiguen los valores únicos y la cantidad de elementos en la variable (n)
  valores <- unique(x)
  n <- length(x)
  
  # Se crea un vector de 0s para guarar las probabilidades
  probabilidades <- matrix(0, nrow = length(valores), ncol = 1)

  # Se calcula las probabilidad de cada valor único (el porcentaje de ese elemento en la variable)
  for (i in 1:length(valores)) {
    c <- 0
    for (j in 1:n) {
      if (x[j] == valores[i]) {
        c <- c + 1
      }
    }
    probabilidades[i] <- c / n
  }

  # Se calcula la entropía
  entropia <- 0
  for (p in probabilidades) {
    entropia <- entropia - p * (log(p) / log(2))
  }
  return(entropia)
}


# Función para calcular el AUC
auc_function <- function(dataset) {
  
  # Ordenar el dataset (la primera columna con los valores de la variable)
  dataset_ordenada <- dataset[order(dataset[,1], decreasing = TRUE), ]
   
  # Calcular la cantidad de positivos (sumando la cantidad de TRUE) y la cantidad de negativos (FALSE)
  num_positivos <- sum(dataset_ordenada[,2] == TRUE)
  num_negativos <- sum(dataset_ordenada[,2] == FALSE)

  TP <- 0
  FP <- 0
  TPRs <- c()
  FPRs <- c()

  # Se calcula la media de la variable. Los elementos mayores que la media serán considerados como positivos y los menores como negativos
  media <- sum(dataset_ordenada[,0])/nrow(dataset_ordenada)
  
  for (i in 1:nrow(dataset_ordenada)) {
    # Se calcula la cantidad de true positives (los elementos predichos como TRUE y que son en realdiad TRUE)
    if (dataset_ordenada[i, 1] >= media){
      if (dataset_ordenada[i, 2] == TRUE) {
        TP <- TP + 1
      }
    # Se calcula la cantidad de false positives (los elementos predichos como TRUE y que son en realdiad FALSE)
      else {
        FP <- FP + 1
      }
    }

    # Se calcula el ratio de los true positives y de los false positives
    TPR <- TP / num_positivos
    FPR <- FP / num_negativos
  
    TPRs <- c(TPRs, TPR)
    FPRs <- c(FPRs, FPR)
  }

  # Calcular el AUC usando el método del trapecio: sumar al AUC anterior la base (el ratio de falsos positivos) * la altura (el ratio del verdadero positivo)
  AUC <- 0
  for (i in 2:length(TPRs)) {
    base <- FPRs[i] - FPRs[i - 1]
    altura <- (TPRs[i] + TPRs[i - 1]) / 2
    AUC <- AUC + base * altura
  }
  return(list(TPR = TPRs, FPR = FPRs, AUC = AUC))
 }