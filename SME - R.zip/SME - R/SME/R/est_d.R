#' Función para estandarizar un dataset.
#'
#' @description
#' Esta función estandariza un dataset eliminandole a los elementos de una columna su media y dividiendolo por su desviación estandar
#' @param dataset El dataset que se quiere estandarizar.
#' @return El dataset estandarizado.
#' @examples
#' df <- data.frame(
#' V1 = c(1.5, 2.3, 3.1, 4.6, 5.8),
#' V2 = c(10.2, 15.6, 20.1, 25.5, 30.0),
#' V3 = c(1.1, 2.2, 1.3, 1.4, 0.95))
#' dataset_estandarizado <- estandarizar_dataset(df)

# Función para estandarizar un dataset
estandarizar_dataset <- function(dataset) {
  
  # Se hace una copia del dataset que se quiere estandarizar
  dataset_estandarizado <- dataset
  
  for (j in 1:length(dataset)) {
    
    # Se estandariza la columna del dataset utilizando la función implementada anteriormente
    dataset_estandarizado[,j] <- estandarizar_variable(dataset[,j])
  }
  return(dataset_estandarizado)
}