#' Función para normalizar una variable.
#'
#' @description
#' Esta función normaliza una la variable transformando los datos mediante el método min-max para que estén dentro del rango entre 0 y 1.
#' @param variable La variable que se quiere normalizar.
#' @return La variable normalizada.
#' @examples
#' variable <- c(1.5, 2.3, 3.1, 4.6, 5.8)
#' variable_normalizada <- normalizar_variable(variable)

# Función para normalizar una variable
normalizar_variable <- function(variable) {
  
  # Solo se normaliza la variable si es numerica
  if (class(variable) == "numeric"){
    
    # Se normaliza la variable utilizandoel método max - min
    variable_normalizada <- as.matrix(variable - min(variable))/(max(variable - min(variable)))
  }
  return (variable_normalizada)
}
