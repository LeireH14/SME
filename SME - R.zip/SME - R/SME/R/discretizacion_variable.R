#' Función para discretizar una variable
#'
#' @description
#' Esta función discretiza una variable utilizando los métodos igual anchura o igual frecuencia o dándole directamente los puntos de corte a utilizar.
#' @param x El atributo que se quiere discretizar.
#' @param num.bins Para el método igual anchura, el número de intervalos a utilizar.
#' @param method El método que se quiere utilizar para discretizar la variable. Si method = 1, se utiliza el método igual anchura. Si method = 2, se utilzia el método igual a frecuencia. Por defecto, method = 1.
#' @param cut.points Los puntos de corte que se quieren utilizar para discretizar la variable. Si la función recibe esta información, no utilizará ningún otro método.
#' @return La variable discretizada junto con los puntos de corte utilizados.
#' @examples
#' variable <-sample(1:100, 10, replace = TRUE)
#'
#'Discretización usando el método de igual anchura con 3 intervalos
#'discretize_variable <- discretize_v(variable, num.bins = 3, method = 1)
#'
#'Discretización usando el método de igual frecuencia con 4 intervalos
#'discretized_variable <- discretize_v(variable, num.bins = 4, method = 2)
#'
discretize_v <- function(x, num.bins = NULL, method = 1, cut.points = NULL) {
  # Se convierte la variable x en un vector (as.matrix) y se crea un vector con 0 para el atributo discretizado
  atributo <- as.matrix(x)
  atributo_discretizado <- matrix(0, nrow = nrow(atributo), ncol = 1)
  
  # Si cut.points está vacío, se tiene en cuenta el párametro "method"
  if (is.null(cut.points)){
    
    # Vector de ceros para guardar los puntos de corte
    cortes <- matrix(0, nrow = as.numeric(num.bins+1), ncol = 1)
    
    # Método igual anchura (uniformemente distribuidos en el rango de los valores)
    if (method == 1){
      
      #Se calcula el valor entre los intervalos
      valor_min <- min(atributo)
      valor_max <- max(atributo)
      valor_intervalo <- (valor_max - valor_min) / num.bins
      
      # Se calculan los cortes con esos intervalos
      for (i in 1:num.bins) {
        cortes[i+1,] <- valor_min + i * valor_intervalo
      }
      
      # Se añaden -infinito e infinito al principio y final de los cortes para poder utilizarlo con futuros datos
      cortes[1,] <- -Inf
      cortes[num.bins+1,]<-Inf
      
      # Si el valor de la variable está dentro del intervalo, se le asigna ese intervalo (I + número de intervalo)
      for (i in 1:num.bins) {
        for (n in 1:nrow(atributo_discretizado)){
          if(atributo[n,] > cortes[i] & atributo[n,] <= cortes[i+1]){
            atributo_discretizado[n,] <- paste("I", i, sep = "")
            }
          }
        }
      }

    # Método igual frecuencia (misma cantidad de valores en los intervalos)
    else if (method == 2) {
      
      # Calcular el valor entero y el del residuo de la división entre la cantidad de elementos y la cantidad de intervalos (para saber si son mútliplos o no)
      valor_entero <- nrow(atributo)%/%num.bins
      valor_residuo <- nrow(atributo)%%num.bins
      
      # Ordenar los valores del atributo
      valores_ordenados <- order(atributo)
      
      cont <- 0
      
      # Se crea un vector de 1s para guardar la secuencia de índices de los datos que servirá para dividirlos después en intervalos
      seq <- matrix(1, nrow = num.bins + 1, ncol = 1)
      
      # Se le dan valores a la secuencia: El primer valor será el índice 1 (el valor más pequeño)
      # Se le irá sumando el valor entero de la división, que será la cantidad de elementos que habrá en cara intervalo
      # Se consiguen los índices que definen los intervalos
      for (i in 1:num.bins){
        seq[i+1,] <- seq[i,] + valor_entero
      }
      
      # Si la cantidad de intervalso y la cantidad de elementos en la variable no son múltiplos, se imprimirá una advertencia. 
      # Los primeros "valor_residuo" intervalos tendrán un elemento más que el resto
        if (valor_residuo!=0){
          print("¡Cuidado! El número de elementos en la variable no es multiplo de la cantidad de intervalos")
          
          # Se calcula la nueva sequencia para que los primeros intervalos tengan un elemento más
           for (res in 1:valor_residuo){
            seq[(res+1):nrow(seq),] <- seq[(res+1):nrow(seq),] + 1
        }
      }
      
      for (i in 1:(nrow(seq)-1)){
        cont <- cont + 1
        
        # Se calculan los índices de los elementos para cada intervalo
        indices<-valores_ordenados[seq[i,]:(seq[i+1,]-1)]
        
        # A los valores con esos índices se les asigna ese intervalo
        atributo_discretizado[indices] <- paste("I", cont, sep = "")
            
        # Se guarda el valor máximo del intervalo actual como un punto de corte
        max_valor <- max(atributo[indices])
        cortes[cont+1,] <- max_valor
        }
      
      # Se les agrega -infinito e infinito al principio y final
      cortes[nrow(cortes),1] <- Inf
      cortes[1,] <- -Inf
  }

    # Si se le dá a la función los puntos de corte, se utiliza ese dato (se ignora el método seleccionado)
    else{
      cut.points <- as.matrix(cut.points)
      
      # Se crea una matriz de 0s para adaptar los cortes devueltos
      cortes <- matrix(0, nrow = nrow(cut.points)+2, ncol = 1)
      
      # Se añade -infinito e infinito
      cortes[1] <- -Inf
      cortes[nrow(cut.points)+2] <- Inf
    
      # Se añaden los puntos de corte
      for(c in 1:nrow(cut.points)){
        cortes[c+1]<-cut.points[c]
      }
  
      # Con esos puntos de corte, se le asigna a cada valor un intervalo
      for (i in 1:nrow(cortes)) {
        for (n in 1:nrow(atributo_discretizado)){
          if(atributo[n,] > cortes[i] & atributo[n,] <= cortes[i+1]){
            atributo_discretizado[n,] <- paste("I", i, sep = "")
          }
        }
      }
    }
  }
  return(list(variable = atributo_discretizado, cortes = cortes))
}
