#' Función para estandarizar una variable.
#'
#' @description
#' Esta función estandariza una la variable eliminandole la media y dividiendola por la desviación estandar.
#' @param variable La variable que se quiere estandarizar.
#' @return La variable estandarizada.
#' @examples
#' variable <- c(1.5, 2.3, 3.1, 4.6, 5.8)
#' variable_estandarizada <- estandarizar_variable(variable)
#'
# Función para estandarizar una variable
estandarizar_variable <- function(variable) {
  
  # Solo se estandarizan las variables numéricas
  if (class(variable) == "numeric"){
    
    # Se estandariza la variable eliminando a cada elemento la media y dividiéndolo por la desviación estandar
    variable_estandarizada <- (variable - mean(variable)) / sqrt(sum((variable - mean(variable))^2))
  }
  return (as.matrix(variable_estandarizada))
}