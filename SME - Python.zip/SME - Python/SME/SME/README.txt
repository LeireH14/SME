# Paquete SME

Este paquete proporciona herramientas para el análisis de datos, incluyendo funciones para calcular métricas, normalizar y estandarizar datos, filtrar datasets y visualizar correlaciones.

## Instalación

Puedes instalar el paquete utilizando pip:

```bash
pip install .
