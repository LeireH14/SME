# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:43:00 2024

@author: euska
"""

import pandas as pd
import numpy as np


# Función para normalizar una variable
def normalizar_variable(variable):

    # Aplicar la normalización a las variables numéricas (int y float)
    if type(variable[0])==np.float64 or type(variable)==np.int32:

        # Normalizarla con el método max-min: se elimina el valor mínimo a la variable y se le divide la resta entre el máximo y el mínimo
        variable_normalizada = (variable - np.min(variable)) / (np.max(variable) - np.min(variable))
        return variable_normalizada

    else:
        print("La variable no es numérica")
        return variable
    
    
# Función para normalizar un dataset
def normalizar_dataset(dataset):

    # Se hace una copia del dataset para guardar los valores normalizados
    dataset_normalizado = dataset.copy()

    # Se normaliza el dataset por columnas
    for col in dataset.columns:
        
        # Se utiliza la función implementada anteriormente para normalizar la variable actual 
        dataset_normalizado[col] = normalizar_variable(dataset[col])
        
    return dataset_normalizado