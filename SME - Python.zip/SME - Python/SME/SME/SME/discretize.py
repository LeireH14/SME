# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:40:41 2024

@author: euska
"""

import pandas as pd
import numpy as np


# Función para discretizar una variable
def discretize_v(x, num_bins=None, method=1, cut_points=None):

    # Se crea un atributo formato array con una columna y tantas filas como sea necesarias
    atributo = np.array(x).reshape(-1, 1)

    # Se crea un array vacío con las dimensiones de "atributo" para guardad los resultados
    atributo_discretizado = np.full(atributo.shape, '', dtype=object)

    # Si no se le entrega a la función los puntos de corte:
    if cut_points is None:

        # Se crea un array de zeros para guardar los valores de los puntos de corte
        cortes = np.zeros((num_bins + 1, 1))

        # Si el método es igual anchura:
        if method == 1:

            # Se calcula el tamaño del intervalo (la cantidad de elementos que irán en cada intervalo)
            valor_min = np.min(atributo)
            valor_max = np.max(atributo)
            valor_intervalo = (valor_max - valor_min) / num_bins

            # Se calculan y guardan los puntos de corte 
            for i in range(1, num_bins + 1):
                cortes[i] = valor_min + i * valor_intervalo

            # Se agrega el valor -infinito y el valor infinito al principio y final del array de cortes
            cortes[0] = -np.inf
            cortes[num_bins] = np.inf

            for i in range(num_bins):
                for n in range(atributo.shape[0]):
                    if cortes[i] < atributo[n] <= cortes[i + 1]:
                        atributo_discretizado[n] = f"I{i + 1}"
                        
        # Si el método es igual a frecuencia:
        elif method == 2:

            # Se calcula el valor entero y el valor del residuo entre la cantidad de elementos en la variable y la cantidad de intervalos
            valor_entero = atributo.shape[0] // num_bins
            valor_residuo = atributo.shape[0] % num_bins

            # Se ordenan los elementos de la variable
            valores_ordenados = np.argsort(atributo, axis=0)
            cont = 0

            # Se crea un array de 1s para guardar la secuencia de puntos de cortes que se van a utilizar para dividir los datos
            seq = np.zeros(num_bins + 1, dtype=int)

            for i in range(1, num_bins + 1):

                # Se le dan valores a la secuencia: El primer valor será el índice 1 (el valor más pequeño)
                # Se le irá sumando el valor entero de la división, que será la cantidad de elementos que habrá en cara intervalo
                # Se consiguen los índices que definen los intervalos
                seq[i] = seq[i - 1] + valor_entero

            # Si la cantidad de elementos no es múltiplo a la cantidad de intervalos
            if valor_residuo != 0:

                # Si la cantidad de intervalso y la cantidad de elementos en la variable no son múltiplos, se imprimirá una advertencia. 
                # Los primeros "valor_residuo" intervalos tendrán un elemento más que el resto
                print("¡Cuidado! El número de elementos en la variable no es múltiplo de la cantidad de intervalos")
                for res in range(1, valor_residuo + 1):
                    seq[res + 1:] += 1
            
            for i in range(num_bins):
                cont += 1

                # Se calculan los índices de los elementos para cada intervalo
                indices = valores_ordenados[seq[i]:seq[i + 1]]

                # A los valores con esos índices se les asigna ese intervalo
                atributo_discretizado[indices] = f"I{cont}"
                
                # Se guarda el valor máximo del intervalo como un punto de corte
                max_valor = np.max(atributo[indices])
                cortes[cont] = max_valor

            # Se agrega -infinito e infinito al principio y final
            cortes[num_bins] = np.inf
            cortes[0] = -np.inf

    # Si se la da a la función los puntos de corte, se ignorará el método seleccionado y se utilizarán estos puntos 
    else:
        cut_points = np.array(cut_points).reshape(-1, 1)
        
        # Se crea un array de 0s para guardar los valores de los cortes en un formato más adecuado
        cortes = np.zeros((cut_points.shape[0] + 2, 1))
        
        # Se añade -infinito e infinito al principio y al final
        cortes[0] = -np.inf
        cortes[-1] = np.inf

        # Se agregan los puntos de corte al nuevo array "cortes"
        for c in range(cut_points.shape[0]):
            cortes[c + 1] = cut_points[c]

        # Con los puntos de corte, se asignan valores a cada intervalo
        for i in range(1, cortes.shape[0]):
            for n in range(atributo.shape[0]):
                if cortes[i - 1] < atributo[n] <= cortes[i]:
                    atributo_discretizado[n] = f"I{i}"

    return {"variable": atributo_discretizado, "cortes": cortes}



# Función para discretizar un dataset completo
def discretize_dataset(x, num_bins=None, method=1, cut_points=None):
    dataset = np.array(x)
    
    # Se crea una matriz de 0s para guardar los valores del dataset discretizados
    dataset_discretizado = np.zeros(dataset.shape, dtype=object)
    
    # Se crea una matiz de zeros para guardar los valores de los cortes
    cortes = np.zeros((num_bins + 1, dataset.shape[1]))

    # La discretización se hace por columnas
    for l in range(dataset.shape[1]):

        # Se consigue la variable (columna) actual
        atributo = dataset[:, l].reshape(-1, 1)

        # Se consiguen la variable discretizada y sus puntos de corte
        resultado = discretize_v(atributo, num_bins=num_bins, method=method, cut_points=cut_points)

        # Se guarda la variable discretizada y sus puntos de corte
        dataset_discretizado[:, l] = resultado["variable"].flatten()
        cortes[:, l] = resultado["cortes"].flatten()

    return {"dataset_discretizado": dataset_discretizado, "cortes": cortes}

