# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:48:17 2024

@author: euska
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# SE UTILIZAN OTRAS FUNCIONES

def plot_auc(atributo, class_bin):

    # Nos aseguramos de que sean arrays
    atributo = np.array(atributo)
    class_bin = np.array(class_bin)

    # Creamos una matriz de 0s para guardar los datos para la función auc_function()
    data_auc = np.zeros((len(atributo), 2))
    
    # Agregamos el atributo en la primera columna y la clase binaria en la segunda columna
    data_auc[:, 0] = atributo
    data_auc[:, 1] = clase_bin

    # Calculamos el AUC y los TPRs Y FPRs
    resultados = auc_function(data_auc)
    AUC = resultados["AUC"]
    TPR = resultados["TPR"]
    FPR = resultados["FPR"]

    # Se plotea la curva ROC
    plt.figure(figsize=(8, 6))
    plt.plot(FPR, TPR, color='blue', label='Curva ROC (AUC = {:.2f})'.format(AUC))
    plt.title('Curva ROC')
    plt.xlabel('Tasa de Falsos Positivos (FPR)')
    plt.ylabel('Tasa de Verdaderos Positivos (TPR)')
    plt.legend(loc="lower right")
    plt.grid()
    plt.show()





# SE UTILIZAN OTROS PAQUETES

# Función para plotear la correlación/información mútua
def plot_info_mutua(dataset):

    # Calculamos la matriz de correlación/información mútua con la función implementada antes
    correlation_matrix = correlacion_mutua(dataset)

    # Crear un mapa de calor
    # Se crea la figura (tamaño 10 x 8) y los ejes del plot
    fig, ejes = plt.subplots(figsize=(10, 8))
    
    # Crear una máscara de los valores iguales a 0, para que las casillas sean blancas (para los valores que no sea han calculado)
    mask = correlation_matrix == 0
    
    # Mostrar el mapa de calor con la máscara aplicada
    heatmap = ejes.matshow(np.ma.masked_where(mask, correlation_matrix), cmap='coolwarm')
    plt.colorbar(heatmap)
    
    # Se ponen los ticks (marcas) de los ejes x e y
    ejes.set_xticks(np.arange(len(df.columns)))
    ejes.set_yticks(np.arange(len(df.columns)))

    # Se ponen las etiquetas (los nombres de las columnas) a las marcas
    ejes.set_xticklabels(df.columns)
    ejes.set_yticklabels(df.columns)

    # Usar tres bucles for para iterar sobre la matriz
    for i in range(correlation_matrix.shape[0]):          
        for j in range(correlation_matrix.shape[1]): 
            
            # Se obtiene el valor en la posición (i, j)
            val = correlation_matrix[i, j]
            if val != 0:    
                # Mostrar los valores en cada celda (centradas en el centro)
                ejes.text(j, i, f"{val:.2f}", ha='center', va='center')

    plt.title("Matriz de Correlación e Información Mutua")
    plt.show()