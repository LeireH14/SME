# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:46:07 2024

@author: euska
"""

import pandas as pd
import numpy as np



# SE UTILIZAN MÁS FUNCIONES IMPLEMENTADAS EN OTROS ARCHIVOS

# Función para filtrar un dataset en base a una métrica y una condición
def filtrar_dataset(dataset, clase_bin=None, metric="entropia", condition=">1"):
    
    # Obtenemos el operador y el valor de la condición
    operator = condition[0]
    value = float(condition[1:])

    # Calculalmos las métricas con la función implementada anteriormente
    results = metrics(dataset, clase_bin)

    # Creamos una lista vacía para guardar las columnas que cumplan la condición
    columnas = []

    # Si la métrica elegida es la entropía:
    if metric == "entropia":

        # Conseguimos los valores de las entropías y las columnas a las que pertenecen
        entropias = results['entropy']['value']
        col = results['entropy']['col']
        
        count = 0

        # Por cada entropía calculada, se ve si cumple la condición y se guardan las columnas de las que sí
        for e in entropias:
            if operator == ">" and e > value:
                columnas.append(col[count])
            elif operator == "<" and e < value:
                columnas.append(col[count])
            elif operator == ">=" and e >= value:
                columnas.append(col[count])
            elif operator == "<=" and e <= value:
                columnas.append(col[count])
            elif operator == "==" and e == value:
                columnas.append(col[count])
            count += 1

    # Si la métrica elegida es el AUC:
    elif metric == "AUC":

        # Conseguimos los valores del AUC y las columnas a las que pertenecen
        AUC = results['auc']['value']
        col = results['auc']['col']

        count = 0

        # Por cada AUC calculado, se ve si cumple la condición establecida y se guardan las columnas de las que sí
        for a in AUC:
            if operator == ">" and a > value:
                columnas.append(col[count])
            elif operator == "<" and a < value:
                columnas.append(col[count])
            elif operator == ">=" and a >= value:
                columnas.append(col[count])
            elif operator == "<=" and a <= value:
                columnas.append(col[count])
            elif operator == "==" and a == value:
                columnas.append(col[count])
            
            count +=1

    # Si la métrica elegida es la varianza:
    elif metric == "varianza":

        # Conseguimos los valores de las varianzas y los números de las columnas
        varianza = results['varianza']['value']
        col = results['varianza']['col']

        count = 0

        # por cada varianza calculada, se mira si cumplen la condición y se guardan las columnas de las que sí
        for v in varianza:
            if operator == ">" and v > value:
                columnas.append(col[count])
            elif operator == "<" and v < value:
                columnas.append(col[count])
            elif operator == ">=" and v >= value:
                columnas.append(col[count])
            elif operator == "<=" and v <= value:
                columnas.append(col[count])
            elif operator == "==" and v == value:
                columnas.append(col[count])
            count += 1
    
    # Se guardan los datos que cumplan las condiciones
    dataset_filtrado = dataset[columnas]
    return dataset_filtrado