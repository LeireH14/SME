# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:45:00 2024

@author: euska
"""

import pandas as pd
import numpy as np


# Función para estandarizar una variable
def estandarizar_variable(variable):

    # Solo se aplica la estandarización a valores numéricos
    if type(variable[0])==np.float64 or type(variable)==np.int32:

        # Se calcula la media
        media = np.sum(variable) / len(variable)
        
        suma_cuadrados = 0

        # Se calcula la desviación estandar
        for valor in variable:
            suma_cuadrados += ((valor-media) ** 2)
            
        desv = (suma_cuadrados / (len(variable) - 1))** 0.5

        # Se estandariza la variable eliminandole la media y dividiéndolo por la desviación estandar
        variable_estandarizada = (variable - media) / desv

        # Convertir a formato de matriz (columna)
        return variable_estandarizada

    else:
        print("La variable no es numérica")
        return variable
    
    
    
# Función para estandarizar un dataset completo
def estandarizar_dataset(dataset):
    
    # Hacer una copia del dataset original
    dataset_estandarizado = dataset.copy()  

    # Se estandariza por columnas
    for col in dataset.columns:

        # Se estandariza la variable utilizando la función implementada anteriormente
        dataset_estandarizado[col] = estandarizar_variable(dataset[col])
        
    return dataset_estandarizado