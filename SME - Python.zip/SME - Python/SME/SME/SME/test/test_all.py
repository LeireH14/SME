import unittest
import numpy as np
import pandas as pd
from SME.metrics import metrics, varianzas_function, entropy_function, auc_function
from SME.normalization import normalizar_variable, normalizar_dataset
from SME.standardization import estandarizar_variable, estandarizar_dataset
from SME.filtering import filtrar_dataset
from SME.correlation import correlacion_mutua, informacion_mutua, calcular_pearson
from SME.plotting import plot_auc, plot_info_mutua

class TestPackageFunctions(unittest.TestCase):

    def setUp(self):
        # Datos de prueba
        self.dataset = np.array([[0, 1], [1, 0], [0, 1], [1, 1]])
        self.clase_bin = np.array([0, 1, 0, 1])
        self.variable = np.array([1, 2, 3, 4, 5])
        self.data_frame = pd.DataFrame({
            'A': [1, 2, 3, 4],
            'B': [1, 2, 3, 4],
            'C': [1, 0, 1, 0]
        })

    def test_varianzas_function(self):
        result = varianzas_function(self.dataset[:, 0])
        self.assertIsInstance(result, float)

    def test_entropy_function(self):
        result = entropy_function(self.clase_bin)
        self.assertIsInstance(result, float)

    def test_auc_function(self):
        result = auc_function(np.column_stack((self.dataset[:, 0], self.clase_bin)))
        self.assertIn("AUC", result)

    def test_normalizar_variable(self):
        result = normalizar_variable(self.variable)
        self.assertTrue(np.all(result >= 0) and np.all(result <= 1))

    def test_normalizar_dataset(self):
        result = normalizar_dataset(self.data_frame)
        self.assertTrue(np.all(result >= 0) and np.all(result <= 1))

    def test_estandarizar_variable(self):
        result = estandarizar_variable(self.variable)
        self.assertEqual(result.mean(), 0)

    def test_estandarizar_dataset(self):
        result = estandarizar_dataset(self.data_frame)
        self.assertEqual(result.mean(axis=0).all(), 0)

    def test_filtrar_dataset(self):
        result = filtrar_dataset(self.data_frame, clase_bin='C', metric='entropia', condition='>0.5')
        self.assertIn('A', result.columns)

    def test_correlacion_mutua(self):
        result = correlacion_mutua(self.dataset)
        self.assertEqual(result.shape, (2, 2))

    def test_informacion_mutua(self):
        result = informacion_mutua(self.dataset[:, 0], self.dataset[:, 1])
        self.assertIsInstance(result, float)

    def test_calcular_pearson(self):
        result = calcular_pearson(self.dataset[:, 0], self.dataset[:, 1])
        self.assertEqual(result, 1.0)

    def test_plot_auc(self):
        # No se puede verificar la salida gráfica, pero podemos comprobar que no lanza un error
        try:
            plot_auc(self.variable, self.clase_bin)
        except Exception:
            self.fail("plot_auc raised an exception unexpectedly!")

    def test_plot_info_mutua(self):
        # No se puede verificar la salida gráfica, pero podemos comprobar que no lanza un error
        try:
            plot_info_mutua(self.dataset)
        except Exception:
            self.fail("plot_info_mutua raised an exception unexpectedly!")

if __name__ == '__main__':
    unittest.main()
