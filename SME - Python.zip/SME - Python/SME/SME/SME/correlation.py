# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:47:44 2024

@author: euska
"""


import pandas as pd
import numpy as np

# Función para calcular la correlación o información mútua
def correlacion_mutua(dataset):
    n = dataset.shape[1]

    # Se crea una matriz de zeros de n x n para guardar las correlaciones entre las variables del dataset
    correlacion_matriz = np.zeros((n, n))

    for i in range(n):
        for j in range(n):

            # Calcular correlación de Pearson para variables continuas
            if (dataset[0,i]-dataset[0,i].astype(int))!=0:
                if (dataset[0,j]-dataset[0,j].astype(int))!=0:

                    # Se utiliza la función implementada más adelante para calcular la correlación
                    correlacion_matriz[i, j] = calcular_pearson(dataset[:, i], dataset[:, j])

            # Calcular información mutua para variables categóricas (valores enteros)
            elif (dataset[0,i]-dataset[0,i].astype(int))==0:
                if (dataset[0,j]-dataset[0,j].astype(int))==0:

                    # Se calcula la informmación mútua utilizando una función implementada más adelante
                    correlacion_matriz[i, j] = informacion_mutua(dataset[:, i], dataset[:, j])

            # Rellenar todos los valores que faltan teniendo en cuenta que la matriz es simétrica
            #correlacion_matriz[j, i] = correlacion_matriz[i, j]
             
    return correlacion_matriz

# Función para calcular la información mútua
def informacion_mutua(x, y):
    n = len(x)

    # Se buscan los elementos únicos de x e y
    valores_x = np.unique(x)
    valores_y = np.unique(y)
    info_mutua = 0

    # Calcular las frecuencias conjuntas y marginales
    for vx in valores_x:
        for vy in valores_y:
            p_xy = np.sum((x == vx) & (y == vy)) / n
            p_x = np.sum(x == vx) / n
            p_y = np.sum(y == vy) / n

            # Se calcula la información mutua
            # Se agrega una pequeña suma para evitar división por cero y log(0)
            info_mutua += p_xy * np.log2(p_xy + 1e-30 / (p_x * p_y + 1e-30))

    return info_mutua

def calcular_pearson(x, y):
    media_x = np.mean(x)
    media_y = np.mean(y)
    covarianza = np.sum((x - media_x) * (y - media_y))
    desviacion_x = np.sqrt(np.sum((x - media_x) ** 2))
    desviacion_y = np.sqrt(np.sum((y - media_y) ** 2))

    correlacion = covarianza / (desviacion_x * desviacion_y)
    return correlacion