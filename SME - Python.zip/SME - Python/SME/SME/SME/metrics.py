# -*- coding: utf-8 -*-
"""
Created on Sun Nov  3 20:41:44 2024

@author: euska
"""
import pandas as pd
import numpy as np

# Definir la función de métrica principal
def metrics(dataset, clase_bin):
    v, a, e = [], [], []
    colv, cole, cola = [], [], []

    # Se calculan las métricas por columnas
    for j in range(len(dataset[0])):
        atributo = dataset[:, j]

        # Se calcula la varianza y el AUC para variables contínuas
        # No se puede utilizar type() porque las matrices no guardan la diferencia entre variables continuas y discretas
        # Se mira si el valor real menos el valor entero dan diferente a cero (float)
        if (atributo-atributo.astype(int)).any()!=0:

            # Se calcula la varianza con una función implementada más adelante
            v.append(varianzas_function(atributo))

            # Se guarda el número de columna al que pertenece la varianza
            colv.append(j)

            # Se crea una matriz de ceros
            data_auc = np.zeros((len(atributo), 2))

            # Se añade los valores de la variable en la primera columna
            data_auc[:, 0] = atributo

            # Se añaden los valores de la clase binaria en la segudna columna
            data_auc[:, 1] = clase_bin

            # Se calcula el AUC con una función implementada más adelante
            a.append(auc_function(data_auc)["AUC"])

            # Se guardan el número de las columnas al que pertenece el valor AUC
            cola.append(j)

        # Se calcula la entropía para variables discretas 
        else:

            # Se calcula la entrpía con una función implementada más adelante
            e.append(entropy_function(atributo))

            # Se guarda el número de columna
            cole.append(j)

    # Se gaurdan los valores en un diccionario
    entropy = {"value": e, "col": cole}
    auc = {"value": a, "col": cola}
    varianza = {"value": v, "col": colv}

    return {"varianza": varianza, "auc": auc, "entropy": entropy}


# Función para calcular varianza
def varianzas_function(atributo):

    # Se calcula la varianza de la mariable
    media = np.mean(atributo)
    sum_square = np.sum((atributo - media) ** 2)
    varianza = sum_square / (len(atributo) - 1)
    return varianza


# Función para calcular entropía
def entropy_function(x):

    # Se guardan los valores únicos de x y cuantas veces aparecen
    valores, counts = np.unique(x, return_counts=True)

    # Se calcula la probabilidad (el porcentaje) de cuantas veces aparece ese valor
    probabilidades = counts / len(x)
    entropia = 0

    for p in probabilidades:
        # Se calcula la entropía
        entropia = entropia-np.sum([p * (np.log2(p))])
    return entropia


# Función para calcular el AUC
def auc_function(dataset):

    # Se ordena el dataset en orden descendente
    dataset_ordenada = dataset[dataset[:, 0].argsort()[::-1]]

    # Calcular la cantidad de positivos (sumando la cantidad de TRUE) y la cantidad de negativos (FALSE)
    num_positivos = np.sum(dataset[:, 1] == True)
    num_negativos = np.sum(dataset[:, 1] == False)

    # Calcular la media: los elementos más grandes que la media se consideraran positivos y los demás negativos
    media = np.sum(dataset_ordenada[:,1])/dataset_ordenada.shape[0]
    
    TP, FP = 0, 0
    TPRs, FPRs = [], []

    # Se suman los verdaderos positivos y los falsos positivos
    for i in range(len(dataset_ordenada)):
        if dataset_ordenada[i, 0] >= media:
            if dataset_ordenada[i, 1] == True:
                TP += 1
            else:
                FP += 1

        # Se guardan los resultados en las listas
        TPRs.append(TP / num_positivos)
        FPRs.append(FP / num_negativos)

    # Se calcula el AUC usando el método del trapecio: base (intervalo de falsos positivos) * altura (media de los verdaderos positivos)
    AUC = 0
    for i in range(1, len(TPRs)):
        base = FPRs[i] - FPRs[i - 1]
        altura = (TPRs[i] + TPRs[i - 1]) / 2
        AUC += base * altura
        
    # Se devuelven los ratiso de TP y de FP y el valor de AUC
    return {"TPR": TPRs, "FPR": FPRs, "AUC": AUC}