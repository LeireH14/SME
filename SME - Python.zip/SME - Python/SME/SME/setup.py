from setuptools import setup, find_packages

setup(
    name='SME',  
    version='0.1.0',  
    author='Leire Hernandez', 
    author_email='leireh.upv@gmail.com', 
    description='Un paquete para análisis de datos y métricas',  
    packages=find_packages(),  
    install_requires=[
        'numpy',
        'matplotlib',
        'pandas'
       
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
